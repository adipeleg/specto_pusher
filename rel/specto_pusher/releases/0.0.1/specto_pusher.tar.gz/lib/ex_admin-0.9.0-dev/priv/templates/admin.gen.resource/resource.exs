defmodule <%= base %>.ExAdmin.<%= resource %> do
  use ExAdmin.Register

  register_resource <%= base %>.<%= resource %> do

  end
end
